import{l as o,a as r}from"../chunks/kHjhtRHu.js";export{o as load_css,r as start};
