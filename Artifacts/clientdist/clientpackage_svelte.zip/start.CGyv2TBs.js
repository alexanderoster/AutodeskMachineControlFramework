import{l as o,a as r}from"../chunks/7ktO76og.js";export{o as load_css,r as start};
