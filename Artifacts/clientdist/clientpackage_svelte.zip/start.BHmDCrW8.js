import{l as o,a as r}from"../chunks/BVaWn_Ly.js";export{o as load_css,r as start};
